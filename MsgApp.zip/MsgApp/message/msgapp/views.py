from django.shortcuts import render,HttpResponse,redirect
from .models import Msg

# Create your views here.
def create(request):
    #return HttpResponse("Hello Linked Successfully")
    print("Request is", request.method)
    if request.method =="GET":
        return render(request,'create.html')
    else:
        n = request.POST['uname'] #formname
        mail = request.POST['email']
        mob = request.POST['mobile']
        msg = request.POST['msg']
        #fetch data from farm
        print("Name",n)
        print("Email",mail)
        print("Mobile",mob)
        print("Message",msg)
        #insert
        Msg.objects.create(name=n,email=mail,mobile=mob,msg=msg)#columnname = variable
        #m.save()
        return redirect('/dashboard')
    
def dashboard(request):
    m = Msg.objects.all()
    print(m)
    context={}
    context['data']= m
    #return HttpResponse("Data fetched from database")
    return render(request,'dashboard.html', context)

def delete(request, rid):
    print("ID to be deleted",rid)
    #return HttpResponse("ID to be deleted "+rid)
    m = Msg.objects.filter(id =  rid);
    m.delete()
    return redirect('/dashboard')

def edit(request, rid):
    print("ID to be edited",rid)
    #return HttpResponse("ID to be edited "+rid)
    if request.method == "GET":


        m = Msg.objects.filter(id =  rid)
        """  print(m)
        print(m[0])
        print(m[0].name) """
        context={}
        context['data']= m
        return render(request,'edit.html', context)
    else:
        uname = request.POST['uname']
        umail = request.POST['email']
        umob = request.POST['mobile']
        umsg = request.POST['msg']
        m = Msg.objects.filter(id =  rid)
        m.update(name=uname,email=umail,mobile=umob,msg=umsg)
        #m.save()
        return redirect('/dashboard')
    