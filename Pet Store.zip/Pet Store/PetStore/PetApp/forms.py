from PetApp.models import Pets
from django.forms import ModelForm
from django import forms

class ViewPets(ModelForm):
    class Meta:
        model = Pets
        fields = "__all__"