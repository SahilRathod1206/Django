from django.shortcuts import render,redirect
from .models import Pets
from .forms import ViewPets

# Create your views here.
def display(req):
    data = Pets.objects.all()
    context = {'data':data}
    return render(req,"display.html",context)

def upload(req):
    if req.method == 'GET':
        context = {}
        form = ViewPets()
        context['form'] = form
        return render(req,"upload.html",context)
    else:
        context = {}
        form = ViewPets(req.POST)
        if form.is_valid():
            form.save()
        context['form'] = form
        return redirect("/")
    
def delete(req,rid):
    x = Pets.objects.filter(id = rid)
    x.delete()
    return redirect("/")

def edit(req,rid):
    data = Pets.objects.get(id=rid)
    if req.method == "POST":
        form = ViewPets(req.POST,instance=data)
        if form.is_valid():
            form.save()
        return redirect('/')
    else:
        form = ViewPets(instance=data)
        context = {
            'form':form,
            'data': Pets
        }
        return render(req,"edit.html",context)
